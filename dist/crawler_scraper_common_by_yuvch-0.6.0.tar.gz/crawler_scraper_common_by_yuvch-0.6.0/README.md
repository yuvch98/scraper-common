# Scraper Package

This is a simple scraper package for job scraping and integration with mongoDB and AWS.