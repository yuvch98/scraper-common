websites = {
    'moon_active' : "https://www.moonactive.com/wp-content/themes/moonactive/assets/comeet/get-jobs.php",
'beach_bum' : "https://www.bbumgames.com/",
'mobile_eye' : "https://careers.mobileye.com/jobs"
}