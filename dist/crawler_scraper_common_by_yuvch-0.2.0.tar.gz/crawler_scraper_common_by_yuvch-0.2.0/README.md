# Scraper Package

This is a simple scraper package.
utilizing mongodb for storing data.
